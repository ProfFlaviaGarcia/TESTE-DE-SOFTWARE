package br.com.senac.leilao.teste;

import org.junit.Test;

import br.com.senac.leilao.dominio.Lance;
import br.com.senac.leilao.dominio.Leilao;
import br.com.senac.leilao.dominio.Usuario;
import br.com.senac.leilao.servico.Avaliador;
import junit.framework.Assert;

public class TesteAvaliador {

@SuppressWarnings("deprecation")
@Test	
public void EntendeLance() {
	//parte1: cenario
	Usuario joao = new Usuario("Joao");
	Usuario Jose = new Usuario("Jose");
	Usuario Maria = new Usuario("Maria");
	
	//vamos criar um leilao e propor lances nesse leilao
	Leilao leilao = new Leilao("Playstation 3 novo");
	
	leilao.propoe(new Lance(joao, 250.0));
	leilao.propoe(new Lance(Jose, 300.0));
	leilao.propoe(new Lance(Maria, 400.0));
	
	//leioleiro ira avaliar o nosso valor no leilao
	//parte2: acao
	Avaliador leiloeiro = new Avaliador();
	leiloeiro.avalia(leilao);
	
	//parte3:validacao
	double maiorEsperado = 400;
	double menorEsperado = 250;

    Assert.assertEquals(maiorEsperado, leiloeiro.getMaiorLance(), 0.00001);
	Assert.assertEquals(menorEsperado, leiloeiro.getMenorLance(), 0.00001);
	
	//System.out.println(maiorEsperado == leiloeiro.getMaiorLance()); //com isso o resutado deve ser 400
	//System.out.println(menorEsperado == leiloeiro.getMenorLance());
}
}