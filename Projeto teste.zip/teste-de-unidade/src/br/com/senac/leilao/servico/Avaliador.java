package br.com.senac.leilao.servico;

import br.com.senac.leilao.dominio.Lance;
import br.com.senac.leilao.dominio.Leilao;

public class Avaliador {
	private double  maiorDeTodos= Double.NEGATIVE_INFINITY; //constante q guarda o menor numero q cabe dentro de um double
	private double menorDeTodos =  Double.POSITIVE_INFINITY;//criado o atributo como positive para que assim toodo mundo sera menor q ele e assim ser� substituido na primeira vez  

	public void avalia (Leilao leilao) {
		
		for (Lance lance : leilao.getLances()) {
		if (lance.getValor( ) > maiorDeTodos) maiorDeTodos = lance.getValor();
		if (lance.getValor( ) < menorDeTodos) menorDeTodos = lance.getValor();
		//inserindo a condi��o para encontrar o menor valor
		//else if (lance.getValor() < menorDeTodos) menorDeTodos = lance.getValor();
		
		}

	}

	 //vamos criar um get 
	 public double getMaiorLance() { //vamos alterar o nome para getMaiorLance
		return maiorDeTodos;
		}
	 
	 public double getMenorLance() {
		return menorDeTodos;
	}
}
